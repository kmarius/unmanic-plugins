import logging

PLUGIN_ID = "kmarius_cache_metadata"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")