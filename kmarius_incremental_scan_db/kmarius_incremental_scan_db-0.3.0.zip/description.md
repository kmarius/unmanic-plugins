# Incremental Library Scan - DB Updater
Updates timestamp database to allow for incremental library scans. The plugin `Incremental Library Scan` is also required for functionality.

This plugin updates timestamps in the database of files that don't need processing. It must be the last plugin in the `File test` flow. 