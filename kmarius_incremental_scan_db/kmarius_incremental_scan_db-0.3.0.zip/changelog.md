**<span style="color:#56adda">0.3.0</span>**
- don't log when `kmarius_incremental_scan` is configured not to

**<span style="color:#56adda">0.2.0</span>**
- move database handling over to `kmarius_incremental_scan` 