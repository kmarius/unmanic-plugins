**<span style="color:#56adda">0.4.2</span>**
- add logging output for updating and resetting timestamps

**<span style="color:#56adda">0.4.1</span>**
- fix a bug where newly created libraries wouldn't load in the panel

**<span style="color:#56adda">0.4.0</span>**
- add misc. settings for the panel
- panel: improve loading times for large libraries

**<span style="color:#56adda">0.3.0</span>**
- send status messages to the ui during scan

**<span style="color:#56adda">0.2.0</span>**
- move database handling over from `kmarius_incremental_scan_db` 
- add data panel