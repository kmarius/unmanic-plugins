import logging

PLUGIN_ID = "kmarius_incremental_scan"

logger = logging.getLogger(f"Unmanic.Plugin.{PLUGIN_ID}")
